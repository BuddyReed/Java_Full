package com.buddy.daikichivariables;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaikichiVariablesApplicationTests {

	@Test
	void contextLoads() {
	}

}
