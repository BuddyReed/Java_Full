package com.buddy.daikichivariables;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaikichiVariablesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaikichiVariablesApplication.class, args);
	}

}
