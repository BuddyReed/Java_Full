public class Test{
    public static void main(String[] args){
        System.out.println("My name is Buddy");
        System.out.println("I am 36 years old");
        System.out.println("My hometown is Sacramento, CA");
    }
}