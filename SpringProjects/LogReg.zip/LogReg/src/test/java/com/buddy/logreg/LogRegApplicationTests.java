package com.buddy.logreg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogRegApplicationTests {

	@Test
	void contextLoads() {
	}

}
