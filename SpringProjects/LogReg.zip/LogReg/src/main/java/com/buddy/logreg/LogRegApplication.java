package com.buddy.logreg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogRegApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogRegApplication.class, args);
	}

}
